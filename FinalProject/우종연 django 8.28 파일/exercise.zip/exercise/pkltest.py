import joblib

clf = joblib.load('./exercise_weight.pkl')

data = [
    ['등'],
]

datatypes = ['운동 부위']

pre = clf.predict(data)
print(pre)

for p in pre:
    print('예측:', datatypes[p])