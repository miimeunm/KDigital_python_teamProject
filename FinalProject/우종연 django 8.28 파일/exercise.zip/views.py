from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from .forms import UploadFileForm
from .models import ImgModel, Exercise
from . import inference

def index(request):
    return render(request, 'exercise/index.html')

def upload(request):
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)

        if form.is_valid():
            form.save()

            img_url = 'media/' + str(form.cleaned_data['file'])

            rs_data = inference.inference(img_url)

            result = ImgModel()
            result.img_data = rs_data['img_data']
            result.ex_class = rs_data['ex_class']
            result.ex_name = rs_data['ex_name']

            result.save()

            return redirect(reverse('exercise:result'))

    else:
        form = UploadFileForm()

    return render(request, 'exercise/upload.html', {'form' : form})

def result(request):
    img = ImgModel.objects.last()
    img_data = img.img_data
    ex_class = img.ex_class
    ex_name = img.ex_name
    
    ex_part_li = ['팔', '허리', '등', '가슴', '가슴', '가슴', '엉덩이', '등', '허벅지', '허벅지', '허벅지', '어깨', '허벅지']
    ex_name_li = ['암컬', '백 익스텐션', '케이블머신', '펙덱 플라이 머신', '체스트 프레스 머신', '어시스트 치닝 앤 디핑 머신', '힙 어브덕션', '랫 풀 다운', '레그 익스텐션', '레그 프레스', '레그 컬 - 라잉', '숄더 프레스 - 머신', '스쿼트 - 스미스 머신']
    
    ex_pred_name = ex_name_li[ex_class]
    ex_pred_part = ex_part_li[ex_class]

    ex_choice = Exercise.objects.get(ex_name = ex_pred_name)
    ci_name = ex_choice.ex_name
    ci_idx = ex_choice.id
    text = ex_choice.ex_exp
    text = text.replace('.', '.<br>')
    text = text.replace(',', '.<br>')

    # print('ex_part 값:', ex_pred_part)
    # print('ex_name 값:', ex_pred_name)

    rs_info = inference.ml_inference(ex_pred_part)
    rs_name = rs_info.ex_name.tolist()
    rs_idx = rs_info.index.tolist()

    name = []
    index = []

    for i, j in zip(rs_name, rs_idx):
        if i == ci_name or j == ci_idx:
            continue

        else:
            name.append(i)
            index.append(j)

    zip_data = zip(name, index)
  
    data_info = {
        'img_data' : img_data,
        'ex_class' : ex_class,
        'ex_name' : ex_name,
        'rs_info' : rs_info,
        'ex_choice' : ex_choice,
        'zip_data' : zip_data,
        'text' : text,
    }

    return render(request, 'exercise/result.html', data_info)

def detail(request, id):

    img = ImgModel.objects.last()
    img_data = img.img_data
    ex_class = img.ex_class
    ex_name = img.ex_name
    
    ex_part_li = ['팔', '허리', '등', '가슴', '가슴', '가슴', '엉덩이', '등', '허벅지', '허벅지', '허벅지', '어깨', '허벅지']
    ex_name_li = ['암컬', '백 익스텐션', '케이블머신', '펙덱 플라이 머신', '체스트 프레스 머신', '어시스트 치닝 앤 디핑 머신', '힙 어브덕션', '랫 풀 다운', '레그 익스텐션', '레그 프레스', '레그 컬 - 라잉', '숄더 프레스 - 머신', '스쿼트 - 스미스 머신']
    
    ex_pred_name = ex_name_li[ex_class]
    ex_pred_part = ex_part_li[ex_class]

    ex_detail = Exercise.objects.get(id=id)
    ex_choice = Exercise.objects.get(ex_name = ex_pred_name)
    ci_name = ex_choice.ex_name
    ci_idx = ex_choice.id
    text = ex_detail.ex_exp
    text = text.replace('.', '.<br>')
    text = text.replace(',', '.<br>')

    # print('ex_part 값:', ex_pred_part)
    # print('ex_name 값:', ex_pred_name)

    rs_info = inference.ml_inference(ex_pred_part)
    rs_name = rs_info.ex_name.tolist()
    rs_idx = rs_info.index.tolist()

    name = []
    index = []

    for i, j in zip(rs_name, rs_idx):
        if i == ci_name or j == ci_idx:
            continue

        else:
            name.append(i)
            index.append(j)

    zip_data = zip(name, index)
  
    data_info = {
        'img_data' : img_data,
        'ex_class' : ex_class,
        'ex_name' : ex_name,
        'rs_info' : rs_info,
        'ex_detail' : ex_detail,
        'ex_choice' : ex_choice,
        'zip_data' : zip_data,
        'text' : text,
    }

    return render(request, 'exercise/detail.html', data_info)

def uploadtest(request):
    return render(request, 'exercise/uploadtest.html')

    ex_detail = Exercise.objects.get(id=id)
    text = ex_detail.ex_exp
    text = text.replace('.', '.<br>')

    context = {
        'ex_detail' : ex_detail,
        'text' : text,
    }

    return render(request, 'exercise/detail.html', context)



# Create your views here.
