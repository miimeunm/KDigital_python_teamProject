import torch
import base64
import io
import joblib
import sqlite3
import pandas as pd
import numpy as np
from PIL import Image

def inference(img):
    model = torch.hub.load('ultralytics/yolov5', 'custom', path='models/best.pt', force_reload=True)
    img = Image.open(img)

    result = model(img, size = 640)
    rs = result.pandas().xyxy[0].to_numpy()

    if len(rs) != 0:
        ex_class = rs[0][5]
        ex_name = rs[0][6]

        result.ims
        result.render()

        for img in result.ims:
            buffered = io.BytesIO()
            img_base64 = Image.fromarray(img)
            img_base64.save(buffered, format='JPEG')
            encode_img = base64.b64encode(buffered.getvalue()).decode('utf-8')

        data = {
            'img_data' : encode_img,
            'ex_class' : ex_class,
            'ex_name' : ex_name
        }

        return data
    
    else:
        return 1
    
def ml_inference(part):

    con = sqlite3.connect('db.sqlite3')
    df = pd.read_sql('SELECT * FROM exercise_exercise', con, index_col = 'id')
    pd.set_option('display.max_colwidth', None)

    ex_weight = joblib.load('./exercise_weight.pkl')
    sorted_idx = ex_weight.argsort()[:, ::-1]

    ex_title = df[df['ex_part'] == part]
    ex_idx = ex_title.index.values
    sim_idx = sorted_idx[ex_idx]
    sim_idx = sim_idx.reshape(-1)
    
    return df.iloc[sim_idx][:6]