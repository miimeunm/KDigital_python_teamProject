from django.db import models
from django.contrib.auth.models import AbstractBaseUser
from django.conf import settings
from django_base64field.fields import Base64Field

class UploadFile(models.Model):
    file = models.FileField(null=True)

    def __str__(self):
        return f'{self.file}'
    
class ImgModel(models.Model):
    img_data = Base64Field(max_length=1000000, blank=True, null=True)
    ex_class = models.IntegerField()
    ex_name = models.CharField(max_length=50)

    def __str__(self):
        return f'file_name : {self.img_data}'

class Exercise(models.Model):

    ex_name = models.CharField(max_length=100, blank=True)
    ex_part = models.CharField(max_length=50, blank=True)
    ex_exp = models.TextField()
    ex_video1 = models.TextField(null = True)
    ex_video2 = models.TextField(null = True)

    def __str__(self):
        return f'name : {self.ex_name}, part : {self.ex_part}, exp : {self.ex_exp}'

# Create your models here.
