from django import forms
from .models import UploadFile, ImgModel

class UploadFileForm(forms.ModelForm):
    class Meta:
        model = UploadFile
        fields = ['file']

    file = forms.FileField(required=False)

class ImgModelForm(forms.ModelForm):
    class Meta:
        model = ImgModel
        fields = ['img_data', 'ex_class', 'ex_name']